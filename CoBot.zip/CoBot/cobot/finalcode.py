import streamlit as st
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains.question_answering import load_qa_chain
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv

# Load environment variables and configure Gemini API
load_dotenv()
genai.configure(api_key=os.getenv("api_key"))

# Set up paths
PDF_FOLDER = "C:/Users/ADMIN/OneDrive/Desktop/CoBot/cobot/carbontrading"
INDEX_PATH = "faiss_index"

# Streamlit page config
st.set_page_config(page_title="Co-Bot", layout="wide")

# Custom CSS for styling
st.markdown("""
<style>
    .stApp {
        background: linear-gradient(to right, #e6f9f9, #d4f4ec);
    }

    h1.title {
        color: #004d40;
        text-align: center;
        font-size: 42px;
        font-weight: bold;
        padding-top: 20px;
    }

    h2.header {
        color: #0f766e;
        text-align: center;
        font-size: 24px;
        font-style: italic;
    }

    .chat-response {
        background-color: #004d40;
        padding: 15px;
        border-radius: 10px;
        margin-top: 20px;
    }

    .chat-response p {
        color: white;
        font-size: 18px;
    }

    .footer {
        text-align: center;
        color: gray;
        font-size: 14px;
        margin-top: 40px;
    }

    input[type="text"], .stTextInput input {
        color: black !important;
        background-color: white !important;
    }

    label, .stTextInput label {
        color: black !important;
        font-weight: bold;
    }

    .stButton>button {
        background-color: #004d40 !important;
        color: white !important;
        font-weight: bold !important;
    }
</style>
""", unsafe_allow_html=True)

# PDF text extraction
def get_pdf_text_from_folder(folder_path):
    text = ""
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".pdf"):
            pdf_path = os.path.join(folder_path, file_name)
            pdf_reader = PdfReader(pdf_path)
            for page in pdf_reader.pages:
                text += page.extract_text()
    return text

# Chunking long text
def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=10000, chunk_overlap=1000)
    return text_splitter.split_text(text)

# Create and save FAISS vector index
def get_vector_store(text_chunks):
    embeddings = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
    vector_store = FAISS.from_texts(text_chunks, embedding=embeddings)
    vector_store.save_local(INDEX_PATH)

# Build RAG pipeline
def get_conversational_chain():
    prompt_template = """
    You are a carbon trading expert with extensive knowledge and experience in the field, adept at answering inquiries across various 
    dimensions of carbon trading including but not limited to market dynamics, credit types, transaction processes, project verification, 
    and compliance reporting. Your extensive expertise allows you to provide comprehensive and precise answers to questions pertaining to carbon trading.

    Context:
    {context}

    Question:
    {question}

    Answer:
    """
    model = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        temperature=0.3,
        google_api_key=os.getenv("api_key")  # ✅ FIXED: API Key passed
    )
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    return load_qa_chain(model, chain_type="stuff", prompt=prompt)

# User input handler
def user_input(user_question):
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/embedding-001",
        google_api_key=os.getenv("api_key")  # ✅ FIXED: API Key passed
    )
    new_db = FAISS.load_local(INDEX_PATH, embeddings, allow_dangerous_deserialization=True)
    docs = new_db.similarity_search(user_question)
    chain = get_conversational_chain()
    response = chain({"input_documents": docs, "question": user_question}, return_only_outputs=True)

    st.markdown(f"""
    <div class="chat-response">
        <h4 style='color:white;'>Reply:</h4>
        <p>{response["output_text"]}</p>
    </div>
    """, unsafe_allow_html=True)

# Preprocess PDF documents
def process_documents():
    with st.spinner("Processing local PDFs..."):
        raw_text = get_pdf_text_from_folder(PDF_FOLDER)
        text_chunks = get_text_chunks(raw_text)
        get_vector_store(text_chunks)
        st.success("Documents loaded and indexed successfully!")

# Main streamlit UI logic
def main():
    st.markdown("<h1 class='title'>Co-Bot: Your Carbon Trading Ally</h1>", unsafe_allow_html=True)
    st.markdown("<h2 class='header'>Sustainable Solutions for a Greener Future</h2>", unsafe_allow_html=True)

    if not os.path.exists(INDEX_PATH):
        process_documents()

    st.markdown("<hr style='border:1px solid #0f766e;'>", unsafe_allow_html=True)

    user_question = st.text_input("Post your queries related to carbon trading, I'm here to help you! 💬")
    if user_question:
        user_input(user_question)

    if st.button("Explore Insights🌱"):
        process_documents()

    st.markdown("""
    <div class='footer'>
        💚 CoBot | Powered by Gemini AI | 2025
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()

